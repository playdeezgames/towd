export default class WorldData {
    static data = {}
}
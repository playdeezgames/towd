export const FlagType = {
    CRAFTING: "CRAFTING"
};
Object.freeze(FlagType);